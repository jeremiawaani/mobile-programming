//Nomor 1

let people = ["Greg", "Mary", "Devon", "James"];
let redefine = ["Greg", "Mary", "Devon", "James"];

// for (let e of people) {
//   console.log(e);
// }

//Nomor 2

// people.forEach(function (peoples) {
//   console.log(peoples);
// });

//Nomor 3

people.shift();
// console.log(people);

//Nomor 4
people.pop();
// console.log(people);

//Nomor 5
people.unshift("Matt");
// console.log(people);

//Nomor 6
people.push("Agung");
// console.log(people);

//Nomor 7
// for (let i = 0; i < people.length; i++) {
//   console.log(people[i]);
//   if (people[i] === "Mary") {
//     break;
//   }
// }

//Nomor 8
peoples = people.slice(2);
// console.log(peoples4);

//Nomor 9
people.splice(2, 1);
console.log(redefine);
